# ScoutBot

SmartScout-style AI-powered Amazon product analyzer.

## Deploy Instructions

1. Upload to GitHub
2. Import into Vercel (https://vercel.com/import)
3. Set environment variable `OPENAI_API_KEY`
4. Click Deploy
